# SignUpForm
email and password validate with sweetalert2
